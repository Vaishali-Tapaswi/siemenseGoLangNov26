package main

import (
"fmt"
"time"
"math/rand"
)
var finaldest string ="" 
var flag = true
func main(){
	
	go print("Goa")
	go print("Kashmir")
	go print("Kanyakumari")
	time.Sleep(2000 * time.Millisecond)
	fmt.Println("The Final Choice is ", finaldest)
}
func print(str string){
	for i:=0;i<10 && flag;i++{
		fmt.Println(str," ", i)
		time.Sleep(time.Duration(rand.Intn(100)) * time.Millisecond)
	}
	if flag==true {
		fmt.Println("The Final Choice is ", str)
		finaldest = str
		flag = false
	}
}
