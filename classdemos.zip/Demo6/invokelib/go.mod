module mymain

go 1.25.1

replace abc.com/calc => ../calclib

require abc.com/calc v0.0.0-00010101000000-000000000000
