package types

import (
    "context"
    "database/sql"
    "errors"
)

var ErrNotFound = errors.New("employee not found")

type Emp struct {
    Empno  int     `json:"empno"`
    Ename  string  `json:"ename"`
    Salary float64 `json:"salary"`
}

// Repository is the CRUD library contract used by the REST layer.
type Repository interface {
    Create(ctx context.Context, e Emp) error
    GetByID(ctx context.Context, empno int) (Emp, error)
    GetAll(ctx context.Context) ([]Emp, error)
    Update(ctx context.Context, e Emp) error
    Delete(ctx context.Context, empno int) error
}

type PostgresRepository struct {
    DB *sql.DB
}

func NewPostgresRepository(db *sql.DB) *PostgresRepository {
    return &PostgresRepository{DB: db}
}

func (r *PostgresRepository) Create(ctx context.Context, e Emp) error {
    _, err := r.DB.ExecContext(ctx,
        `INSERT INTO emptable (empno, ename, salary) VALUES ($1, $2, $3)`,
        e.Empno, e.Ename, e.Salary)
    return err
}

func (r *PostgresRepository) GetByID(ctx context.Context, empno int) (Emp, error) {
    var e Emp
    err := r.DB.QueryRowContext(ctx,
        `SELECT empno, ename, salary FROM emptable WHERE empno = $1`,
        empno).Scan(&e.Empno, &e.Ename, &e.Salary)
    if errors.Is(err, sql.ErrNoRows) {
        return Emp{}, ErrNotFound
    }
    return e, err
}

func (r *PostgresRepository) GetAll(ctx context.Context) ([]Emp, error) {
    rows, err := r.DB.QueryContext(ctx,
        `SELECT empno, ename, salary FROM emptable ORDER BY empno`)
    if err != nil {
        return nil, err
    }
    defer rows.Close()

    emps := make([]Emp, 0)
    for rows.Next() {
        var e Emp
        if err := rows.Scan(&e.Empno, &e.Ename, &e.Salary); err != nil {
            return nil, err
        }
        emps = append(emps, e)
    }
    if err := rows.Err(); err != nil {
        return nil, err
    }
    return emps, nil
}

func (r *PostgresRepository) Update(ctx context.Context, e Emp) error {
    result, err := r.DB.ExecContext(ctx,
        `UPDATE emptable SET ename = $1, salary = $2 WHERE empno = $3`,
        e.Ename, e.Salary, e.Empno)
    if err != nil {
        return err
    }
    n, err := result.RowsAffected()
    if err != nil {
        return err
    }
    if n == 0 {
        return ErrNotFound
    }
    return nil
}

func (r *PostgresRepository) Delete(ctx context.Context, empno int) error {
    result, err := r.DB.ExecContext(ctx,
        `DELETE FROM emptable WHERE empno = $1`, empno)
    if err != nil {
        return err
    }
    n, err := result.RowsAffected()
    if err != nil {
        return err
    }
    if n == 0 {
        return ErrNotFound
    }
    return nil
}
