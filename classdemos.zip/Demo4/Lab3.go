package main

import (
	"os"
	"fmt"
	"encoding/json"
)
type Employee struct {
	Empno   int     `json:"empno"`
	Empname string  `json:"empname"`
	Sal  float64 `json:"salary"`
}

func main() {
	employee := Employee{
		Empno:   1,
		Empname: "Simple ",
		Sal: 20020.20,
	}
	barr, err:=json.Marshal(employee)
	if err != nil {
		fmt.Println("Error occurred:", err)
	}		
	fmt.Println("JSON representation of employee is:", string(barr))
	data, err := os.ReadFile("a1.json")
    if err != nil {
        fmt.Println("Error reading file:", err)
    }
    var obj Employee
    err = json.Unmarshal(data, &obj)
    if err != nil {
        fmt.Println("Error unmarshalling JSON:", err)
    }
	fmt.Println("Employee:", "empno:", obj.Empno, "name:", obj.Empname, "salary:", obj.Sal)

}

