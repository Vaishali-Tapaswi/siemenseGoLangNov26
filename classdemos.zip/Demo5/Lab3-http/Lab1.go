package main

import (
	"fmt"
	"net/http"
	"io"
)

func main(){
	resp, err := http.Get("https://go.dev/wiki/SQLDrivers")
	if err != nil {
		fmt.Println("Get Error " , err)
	}
	defer resp.Body.Close()
	fmt.Println("Status = ", resp.Status, " StatusCode = ", resp.StatusCode)
	
	body, err := io.ReadAll(resp.Body)
	fmt.Println(string(body))

}