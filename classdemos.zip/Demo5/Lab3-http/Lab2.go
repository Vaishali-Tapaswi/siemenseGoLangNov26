package main
 
import (
    "encoding/json"
    "fmt"
    "io"
    "log"
    "net/http"
)
 
type Emp struct {
    Empno   int     `json:"empno"`
    Empname string  `json:"empname"`
    Sal     float64 `json:"salary"`
}
 
var emps = []Emp{
    {Empno: 1, Empname: "Jhon", Sal: 1000},
    {Empno: 2, Empname: "Abraham", Sal: 2000},
}
 
func main() {
 
    http.HandleFunc("/",
        func(w http.ResponseWriter, r *http.Request) {
            fmt.Fprintf(w, "Hello World ")
        })
    http.HandleFunc("/emp",
        func(w http.ResponseWriter, r *http.Request) {
            switch r.Method {
            case http.MethodGet:
                // Marshal: Go struct -> JSON
                data, err := json.Marshal(emps)
                if err != nil {
                    http.Error(w, err.Error(), http.StatusInternalServerError)
                    return
                }
                w.Header().Set("Content-Type", "application/json")
                w.Write(data)
            case http.MethodPost:
                var e Emp
                body, err := io.ReadAll(r.Body)
                if err != nil {
                    http.Error(w, err.Error(), http.StatusInternalServerError)
                    return
                }
                if err := json.Unmarshal(body, &e); err != nil {
                    http.Error(w, "Invalid Employee JSON: "+err.Error(), http.StatusBadRequest)
                    return
                }
                emps = append(emps, e)
                w.WriteHeader(http.StatusCreated)
                fmt.Fprintf(w, "Employee added: %+v", e)
            default:
                http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
            }
        })
    fmt.Println("Starting server on 8080")
    log.Fatal(http.ListenAndServe("localhost:8080", nil))
 
}
 