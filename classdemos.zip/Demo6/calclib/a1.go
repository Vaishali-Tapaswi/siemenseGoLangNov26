package calc

import (
	"fmt"
)

func Add(a, b int) int {
	fmt.Println("in calc package - in add function")
	return a + b
}
func Sub(a, b int) int {
	fmt.Println("in calc package - in sub function")
	return a - b
}
