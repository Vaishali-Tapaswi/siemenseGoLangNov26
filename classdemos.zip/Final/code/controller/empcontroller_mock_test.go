package controller

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"abc.com/code/types"
	"github.com/gin-gonic/gin"
)

// mockRepository implements types.Repository. It stores data in memory,
// so these tests never open a database connection.
type mockRepository struct {
	employees map[int]types.Emp
}

func newMockRepository() *mockRepository {
	return &mockRepository{employees: map[int]types.Emp{
		1: {Empno: 1, Ename: "Asha", Salary: 50000},
	}}
}

func (m *mockRepository) Create(_ context.Context, e types.Emp) error {
	if _, exists := m.employees[e.Empno]; exists {
		return errors.New("employee already exists")
	}
	m.employees[e.Empno] = e
	return nil
}

func (m *mockRepository) GetByID(_ context.Context, empno int) (types.Emp, error) {
	e, ok := m.employees[empno]
	if !ok {
		return types.Emp{}, types.ErrNotFound
	}
	return e, nil
}

func (m *mockRepository) GetAll(_ context.Context) ([]types.Emp, error) {
	result := make([]types.Emp, 0, len(m.employees))
	for _, e := range m.employees {
		result = append(result, e)
	}
	return result, nil
}

func (m *mockRepository) Update(_ context.Context, e types.Emp) error {
	if _, ok := m.employees[e.Empno]; !ok {
		return types.ErrNotFound
	}
	m.employees[e.Empno] = e
	return nil
}

func (m *mockRepository) Delete(_ context.Context, empno int) error {
	if _, ok := m.employees[empno]; !ok {
		return types.ErrNotFound
	}
	delete(m.employees, empno)
	return nil
}

func setupMockRouter() *gin.Engine {
	gin.SetMode(gin.TestMode)
	repo := newMockRepository()
	handler := NewHandler(repo)
	router := gin.New()
	handler.RegisterRoutes(router)
	return router
}

func TestGetAllWithMockRepository(t *testing.T) {
	router := setupMockRouter()
	req := httptest.NewRequest(http.MethodGet, "/emps", nil)
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want %d; body: %s", rec.Code, http.StatusOK, rec.Body.String())
	}
	var employees []types.Emp
	if err := json.Unmarshal(rec.Body.Bytes(), &employees); err != nil {
		t.Fatal(err)
	}
	if len(employees) != 1 || employees[0].Ename != "Asha" {
		t.Fatalf("unexpected employees: %+v", employees)
	}
}

func TestGetByIDWithMockRepository(t *testing.T) {
	router := setupMockRouter()
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/emps/1", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want %d; body: %s", rec.Code, http.StatusOK, rec.Body.String())
	}
}

func TestGetByIDNotFoundWithMockRepository(t *testing.T) {
	router := setupMockRouter()
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/emps/999", nil))
	if rec.Code != http.StatusNotFound {
		t.Fatalf("status = %d, want %d", rec.Code, http.StatusNotFound)
	}
}

func TestCreateWithMockRepository(t *testing.T) {
	router := setupMockRouter()
	body := `{"empno":2,"ename":"Rahul","salary":60000}`
	req := httptest.NewRequest(http.MethodPost, "/emps", bytes.NewBufferString(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusCreated {
		t.Fatalf("status = %d, want %d; body: %s", rec.Code, http.StatusCreated, rec.Body.String())
	}
}

func TestUpdateWithMockRepository(t *testing.T) {
	router := setupMockRouter()
	body := `{"ename":"Asha Updated","salary":65000}`
	req := httptest.NewRequest(http.MethodPut, "/emps/1", bytes.NewBufferString(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)

	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, want %d; body: %s", rec.Code, http.StatusOK, rec.Body.String())
	}
}

func TestDeleteWithMockRepository(t *testing.T) {
	router := setupMockRouter()
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodDelete, "/emps/1", nil))
	if rec.Code != http.StatusNoContent {
		t.Fatalf("status = %d, want %d", rec.Code, http.StatusNoContent)
	}
}

func TestInvalidEmployeeIDWithMockRepository(t *testing.T) {
	router := setupMockRouter()
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/emps/abc", nil))
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("status = %d, want %d", rec.Code, http.StatusBadRequest)
	}
}
