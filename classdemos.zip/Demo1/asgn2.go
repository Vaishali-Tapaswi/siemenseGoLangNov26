package main
 
import (
	"fmt"
	"os"
)
 
func main() {
	totalLen := 0

	for i := 0; i < len(os.Args); i++ {
		fmt.Println(os.Args[i])
		totalLen += lena(os.Args[i])
	}
	fmt.Println("Sum of lengths:", totalLen)
}
 