package dbcomm

import (
    "fmt"
    "net/url"

    "github.com/magiconair/properties"
)

type DBConfig struct {
    Host     string
    Port     string
    Name     string
    User     string
    Password string
    SSLMode  string
}

// LoadDB reads the Java-style .properties file using magiconair/properties.
func LoadDB(filename string) (DBConfig, error) {
    p, err := properties.LoadFile(filename, properties.UTF8)
    if err != nil {
        return DBConfig{}, fmt.Errorf("load %s: %w", filename, err)
    }

    cfg := DBConfig{
        Host:     p.GetString("dbhost", "localhost"),
        Port:     p.GetString("dbport", "5432"),
        Name:     p.GetString("dbname", ""),
        User:     p.GetString("dbuser", ""),
        Password: p.GetString("dbpassword", ""),
        SSLMode:  p.GetString("sslmode", "disable"),
    }
    if cfg.Name == "" || cfg.User == "" {
        return DBConfig{}, fmt.Errorf("dbname and dbuser must be set in %s", filename)
    }
    return cfg, nil
}

// DSN builds a PostgreSQL URL and safely escapes credentials.
func (c DBConfig) DSN() string {
    u := &url.URL{
        Scheme: "postgres",
        Host:   fmt.Sprintf("%s:%s", c.Host, c.Port),
        Path:   c.Name,
    }
    u.User = url.UserPassword(c.User, c.Password)
    q := url.Values{}
    q.Set("sslmode", c.SSLMode)
    u.RawQuery = q.Encode()
    return u.String()
}
