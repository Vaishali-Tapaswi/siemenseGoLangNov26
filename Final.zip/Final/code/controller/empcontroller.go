package controller

import (
    "errors"
    "net/http"
    "strconv"
    "strings"
    "github.com/gin-gonic/gin"
)

type Handler struct {
    Repo emp.Repository
}

func NewHandler(repo emp.Repository) *Handler {
    return &Handler{Repo: repo}
}

func (h *Handler) RegisterRoutes(r *gin.Engine) {
    r.GET("/emps", h.GetAll)
    r.GET("/emps/:empno", h.GetByID)
    r.POST("/emps", h.Create)
    r.PUT("/emps/:empno", h.Update)
    r.DELETE("/emps/:empno", h.Delete)
}

func parseEmpno(c *gin.Context) (int, bool) {
    n, err := strconv.Atoi(c.Param("empno"))
    if err != nil || n <= 0 {
        c.JSON(http.StatusBadRequest, gin.H{"error": "empno must be a positive integer"})
        return 0, false
    }
    return n, true
}

func validate(e emp.Emp) bool {
    return e.Empno > 0 && strings.TrimSpace(e.Ename) != "" && e.Salary >= 0
}

func (h *Handler) GetAll(c *gin.Context) {
    emps, err := h.Repo.GetAll(c.Request.Context())
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "could not retrieve employees"})
        return
    }
    c.JSON(http.StatusOK, emps)
}

func (h *Handler) GetByID(c *gin.Context) {
    empno, ok := parseEmpno(c)
    if !ok { return }

    e, err := h.Repo.GetByID(c.Request.Context(), empno)
    if errors.Is(err, emp.ErrNotFound) {
        c.JSON(http.StatusNotFound, gin.H{"error": "employee not found"})
        return
    }
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "could not retrieve employee"})
        return
    }
    c.JSON(http.StatusOK, e)
}

func (h *Handler) Create(c *gin.Context) {
    var e emp.Emp
    if err := c.ShouldBindJSON(&e); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "invalid JSON body"})
        return
    }
    if !validate(e) {
        c.JSON(http.StatusBadRequest, gin.H{"error": "empno, ename and non-negative salary are required"})
        return
    }
    if err := h.Repo.Create(c.Request.Context(), e); err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "could not create employee"})
        return
    }
    c.JSON(http.StatusCreated, e)
}

func (h *Handler) Update(c *gin.Context) {
    empno, ok := parseEmpno(c)
    if !ok { return }

    var e emp.Emp
    if err := c.ShouldBindJSON(&e); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "invalid JSON body"})
        return
    }
    e.Empno = empno // URL empno is authoritative.
    if strings.TrimSpace(e.Ename) == "" || e.Salary < 0 {
        c.JSON(http.StatusBadRequest, gin.H{"error": "ename and non-negative salary are required"})
        return
    }
    if err := h.Repo.Update(c.Request.Context(), e); errors.Is(err, emp.ErrNotFound) {
        c.JSON(http.StatusNotFound, gin.H{"error": "employee not found"})
        return
    } else if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "could not update employee"})
        return
    }
    c.JSON(http.StatusOK, e)
}

func (h *Handler) Delete(c *gin.Context) {
    empno, ok := parseEmpno(c)
    if !ok { return }

    if err := h.Repo.Delete(c.Request.Context(), empno); errors.Is(err, emp.ErrNotFound) {
        c.JSON(http.StatusNotFound, gin.H{"error": "employee not found"})
        return
    } else if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "could not delete employee"})
        return
    }
    c.Status(http.StatusNoContent)
}
