package main

import "fmt"


func main() {
	helloworld()
	addResult, subResult := calc(10, 5)
	fmt.Println("Returned, sum =  ", addResult, "sub = ", subResult)
}
