package main
 
import "fmt"
 
func swap(a, b string) (string, string) {
    return b, a
}
 
func main() {
    a, b := "hello", "world"
    fmt.Println("Before swap, a:", a, "b:", b)
    a, b = swap(a, b)
    fmt.Println("a:", a, "b:", b)
}