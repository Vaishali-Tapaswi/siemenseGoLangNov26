package main

import (
"fmt"
"time"
)

func main(){
	go hello()
	go world()
	// options 1 -	wait for some input 
	/*
	fmt.Println("enter a number to continue")
	i := 0
	fmt.Scanln(&i)
	*/
	// options 2
	//sleep for some time 
	time.Sleep(100 * time.Millisecond)
}
func hello(){
	for i:=0;i<5;i++{
		fmt.Println("hello")
	}
}
func world(){
	for i:=0;i<5;i++{
		fmt.Println("world")
	}
}
