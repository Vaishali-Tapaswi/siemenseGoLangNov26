module abc.com/calc

go 1.25.1
