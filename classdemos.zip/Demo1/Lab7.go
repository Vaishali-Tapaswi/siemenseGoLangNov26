package main
 
import "fmt"
 
var str  ="Hello outside function "

func main() {
	const str1  ="Hello outside function const"	
	
	fmt.Println("const " ,str1)
	fmt.Println(str)
	str = "Hello in main after redeclaration"
	fmt.Println(str)
	str :="Hello in main "
    fmt.Println(str)
	if str != "" {
		fmt.Println("in if before redeclaration:",str)
		str := "hello in if "
		fmt.Println("in if:",str)
		str = "hello in if after redeclaration"
		fmt.Println("in if:",str)
	}
	fmt.Println("in main:",str)
}
