package dbcomm

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestLoadDB(t *testing.T) {
	dir := t.TempDir()
	file := filepath.Join(dir, "db.properties")
	content := "dbhost=localhost\ndbport=5432\ndbname=employees\ndbuser=testuser\ndbpassword=secret\nsslmode=require\n"
	if err := os.WriteFile(file, []byte(content), 0600); err != nil {
		t.Fatal(err)
	}

	cfg, err := LoadDB(file)
	if err != nil {
		t.Fatalf("LoadDB() error = %v", err)
	}
	if cfg.Host != "localhost" || cfg.Port != "5432" || cfg.Name != "employees" ||
		cfg.User != "testuser" || cfg.Password != "secret" || cfg.SSLMode != "require" {
		t.Fatalf("unexpected config: %+v", cfg)
	}
}

func TestLoadDBRequiresNameAndUser(t *testing.T) {
	dir := t.TempDir()
	file := filepath.Join(dir, "db.properties")
	if err := os.WriteFile(file, []byte("dbhost=localhost\n"), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := LoadDB(file); err == nil {
		t.Fatal("expected validation error when dbname and dbuser are missing")
	}
}

func TestLoadDBMissingFile(t *testing.T) {
	_, err := LoadDB(filepath.Join(t.TempDir(), "missing.properties"))
	if err == nil {
		t.Fatal("expected error for missing properties file")
	}
}

func TestDSN(t *testing.T) {
	cfg := DBConfig{
		Host: "localhost", Port: "5432", Name: "employees",
		User: "test user", Password: "p@ss word", SSLMode: "require",
	}
	dsn := cfg.DSN()
	for _, expected := range []string{"postgres://", "localhost:5432", "/employees", "sslmode=require"} {
		if !strings.Contains(dsn, expected) {
			t.Errorf("DSN() = %q; expected it to contain %q", dsn, expected)
		}
	}
	if strings.Contains(dsn, "p@ss word") {
		t.Errorf("password should be URL-escaped in DSN: %q", dsn)
	}
}
