package calc

import (
	"fmt"
)

func Mult(a, b int) int {
	fmt.Println("in calc package - in mult function")
	return a * b
}
