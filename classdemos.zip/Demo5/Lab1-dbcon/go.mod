module dbdemo

go 1.25.1

require (
	github.com/lib/pq v1.12.3
	github.com/magiconair/properties v1.18.13
)
