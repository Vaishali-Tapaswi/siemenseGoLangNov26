package main

import "fmt"

type Point struct {
	X int
	Y int
}
func (p Point) print() {
	fmt.Println("Details - p.x = ", p.X, "p.y = ", p.Y)
}
func (p *Point) shift(dx, dy int) {
	p.X, p.Y = p.X+dx, p.Y+dy
	fmt.Println("in Shift - p.x = ", p.X, "p.y = ", p.Y)
}
func main() {
	p1 := Point{10, 20}
	fmt.Println(p1)
	p1.print()
	p1.shift(2,3)
	fmt.Println("after shift - p.x = ", p1.X, "p.y = ", p1.Y)
	
}
