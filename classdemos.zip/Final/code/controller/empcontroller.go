package controller

import (
    "errors"
    "net/http"
    "strconv"
    "strings"
    "github.com/gin-gonic/gin"
    "abc.com/code/types"
)

type Handler struct {
    Repo types.Repository
}

func NewHandler(repo types.Repository) *Handler {
    return &Handler{Repo: repo}
}

func (h *Handler) RegisterRoutes(r *gin.Engine) {
    r.GET("/emps", h.GetAll)
    r.GET("/emps/:Empno", h.GetByID)
    r.POST("/emps", h.Create)
    r.PUT("/emps/:Empno", h.Update)
    r.DELETE("/emps/:Empno", h.Delete)
}

func parseEmpno(c *gin.Context) (int, bool) {
    n, err := strconv.Atoi(c.Param("Empno"))
    if err != nil || n <= 0 {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Empno must be a positive integer"})
        return 0, false
    }
    return n, true
}

func validate(e types.Emp) bool {
    return e.Empno > 0 && strings.TrimSpace(e.Ename) != "" && e.Salary >= 0
}

func (h *Handler) GetAll(c *gin.Context) {
    typess, err := h.Repo.GetAll(c.Request.Context())
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "could not retrieve typesloyees"})
        return
    }
    c.JSON(http.StatusOK, typess)
}

func (h *Handler) GetByID(c *gin.Context) {
    Empno, ok := parseEmpno(c)
    if !ok { return }

    e, err := h.Repo.GetByID(c.Request.Context(), Empno)
    if errors.Is(err, types.ErrNotFound) {
        c.JSON(http.StatusNotFound, gin.H{"error": "typesloyee not found"})
        return
    }
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "could not retrieve typesloyee"})
        return
    }
    c.JSON(http.StatusOK, e)
}

func (h *Handler) Create(c *gin.Context) {
    var e types.Emp
    if err := c.ShouldBindJSON(&e); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "invalid JSON body"})
        return
    }
    if !validate(e) {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Empno, ename and non-negative salary are required"})
        return
    }
    if err := h.Repo.Create(c.Request.Context(), e); err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "could not create typesloyee"})
        return
    }
    c.JSON(http.StatusCreated, e)
}

func (h *Handler) Update(c *gin.Context) {
    Empno, ok := parseEmpno(c)
    if !ok { return }

    var e types.Emp
    if err := c.ShouldBindJSON(&e); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "invalid JSON body"})
        return
    }
    e.Empno = Empno // URL Empno is authoritative.
    if strings.TrimSpace(e.Ename) == "" || e.Salary < 0 {
        c.JSON(http.StatusBadRequest, gin.H{"error": "ename and non-negative salary are required"})
        return
    }
    if err := h.Repo.Update(c.Request.Context(), e); errors.Is(err, types.ErrNotFound) {
        c.JSON(http.StatusNotFound, gin.H{"error": "typesloyee not found"})
        return
    } else if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "could not update typesloyee"})
        return
    }
    c.JSON(http.StatusOK, e)
}

func (h *Handler) Delete(c *gin.Context) {
    Empno, ok := parseEmpno(c)
    if !ok { return }

    if err := h.Repo.Delete(c.Request.Context(), Empno); errors.Is(err, types.ErrNotFound) {
        c.JSON(http.StatusNotFound, gin.H{"error": "typesloyee not found"})
        return
    } else if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "could not delete typesloyee"})
        return
    }
    c.Status(http.StatusNoContent)
}
