package main
 
import "fmt"
 
func printFibonacci(limit int) {
    previous, current := 0, 1
    for previous <= limit {
        fmt.Printf("%d ", previous)
        previous, current = current, previous+current
    }
    fmt.Println()
}
 
func main() {
    var limit int
    fmt.Print("Enter a number: ")
    if _, err := fmt.Scan(&limit); err != nil {
        fmt.Println("Please enter a valid integer.")
        return
    }
 
    printFibonacci(limit)
}