package main
import (
	"fmt"
	"github.com/magiconair/properties"
)
func main() {
	p := properties.MustLoadFile("my.properties", properties.UTF8)
	port := p.GetInt("port", 80)
	fmt.Println(port)
	fmt.Println(p.MustGetString("hostname"))
	
}
