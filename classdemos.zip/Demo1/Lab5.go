package main

import (
	"fmt"
	"os"
)

func main() {
	//func Hostname() (name string, err error)
	name, err := os.Hostname()
	if err != nil {
		fmt.Println("Error occurred:", err)
	} else {
		fmt.Println("Hostname is:", name)
	}
	fmt.Println(os.Args)
	fmt.Println("Number of arguments:", len(os.Args))
	fmt.Println("length of second argument:", len(os.Args[0]))
	
}
