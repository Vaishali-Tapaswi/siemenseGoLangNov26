package main

import (
"fmt"
"time"
)

func main(){
	
	go print(".")
	go print("-")
	go print("x")
	time.Sleep(2000 * time.Millisecond)
}
func print(str string){
	for i:=0;i<1000;i++{
		fmt.Print(str)
	}
}
