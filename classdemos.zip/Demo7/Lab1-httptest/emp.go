package main

import (
    "encoding/json"
    "net/http"
    "strconv"
    "strings"
)

type Employee struct {
    EmpNo  int     `json:"empno"`
    EName  string  `json:"ename"`
    Salary float64 `json:"salary"`
}

// In-memory employee store shared by the handlers.
var employees = map[int]Employee{}

func CreateEmployeeHandler(w http.ResponseWriter, r *http.Request) {
 /*
   if r.Method != http.MethodPost {
       http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
       return
    }
*/
    var emp Employee
    if err := json.NewDecoder(r.Body).Decode(&emp); err != nil {
       http.Error(w, "invalid JSON payload", http.StatusBadRequest)
       return
    }
    // Basic validation
    if emp.EmpNo <= 0 || emp.EName == "" || emp.Salary < 0 {
       http.Error(w, "invalid employee details", http.StatusBadRequest)
       return
    }
    employees[emp.EmpNo] = emp
    w.Header().Set("Content-Type", "application/json")
    w.WriteHeader(http.StatusCreated)
    json.NewEncoder(w).Encode(emp)
}

// DeleteEmployeeHandler handles DELETE /employees/{empno}.
// 200 on success, 404 if the employee does not exist,
//  400 for an invalid empno.
func DeleteEmployeeHandler(w http.ResponseWriter, r *http.Request) {
    empNo, err := strconv.Atoi(strings.TrimPrefix(r.URL.Path, "/employees/"))
    if err != nil || empNo <= 0 {
       http.Error(w, "invalid empno", http.StatusBadRequest)
       return
    }
    if _, found := employees[empNo]; !found {
       http.Error(w, "employee not found", http.StatusNotFound)
       return
    }
    delete(employees, empNo)
    w.Header().Set("Content-Type", "application/json")
    w.WriteHeader(http.StatusOK)
    json.NewEncoder(w).Encode(map[string]string{"message": "employee deleted"})
}
 