module abc.com

go 1.25.1
