package main
 
import (
	"fmt"
	"strconv"
)
 

//1. getemp should return emp and err  
func getEmp(empno int) (string, error) {
    if empno%2 != 0 {
        return "", fmt.Errorf("employee number %d not found", empno)
    }
    name := "Name"+strconv.Itoa(empno)
    return name, nil
}
 
func getEmpOrPanic(empno int) string {
    name, err := getEmp(empno)
    if err != nil {
        panic(err)
    }
    return name
}
 
func main() {
    defer func() {
		fmt.Println("in defer function in main")
        if recovered := recover(); recovered != nil {
            fmt.Println("Recovered in main:", recovered)
        }
    }()
 
   if name, err := getEmp(2); err != nil {
            fmt.Println("Error:", err)
    } else {
        fmt.Println("Employee name:", name)
    }
	fmt.Println("In main after getEmp call")
    fmt.Println("Panic option, employee name:", getEmpOrPanic(4))
 	fmt.Println("In main after getEmpOrPanic call")
}
 