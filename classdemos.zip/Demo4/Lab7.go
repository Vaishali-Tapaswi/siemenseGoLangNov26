package main

import (
"fmt"
"time"

)
var finaldest string ="" 
var flag = true
func main(){
	
	ch := make(chan string, 1)
	go Writer(ch)
	go Reader(ch)
	time.Sleep(10000 * time.Millisecond)
}
func Writer(channel chan string ){
	fmt.Println("Writer started")
	fmt.Println("sending first string")
	channel <- "firststring"
	fmt.Println("sent first, now sending second")
	channel <- "secondstring"
	fmt.Println("sent second, now sending third")
	channel <- "thirdstring"
	fmt.Println("sent third")
	close(channel)

}
func Reader(channel chan string ){
	fmt.Println("Reader started")
	// str := <- channel
	for msg := range channel {
	 fmt.Println("in reader " , msg)
	}
}