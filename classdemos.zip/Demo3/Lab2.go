package main

import ("fmt"
	
)

func main(){
	// Array
	var a [2]string
	primes := [6]int{20, 31, 5, 77, 11, 13}
	a[0] = "Hello"
	a[1] = "World"
	fmt.Println(a)
	fmt.Println(primes)
	// Slice 
	//fmt.Println(sort.Ints(primes))
	sl1 := primes[0:3]
	fmt.Println("Slice from primes[0:3]:", sl1)
	sl1[0] = 100
	fmt.Println("Slice after changing sl1[0] to 100:", sl1)
	fmt.Println("Primes after changing sl1[0] to 100:", primes)
	fmt.Println("sl2 primes[3,5]:", primes[3:5])
}