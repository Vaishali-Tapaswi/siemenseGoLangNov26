package main
 
import (
    "fmt"
    "strconv"
)
 
type Employee struct {
    id     int
    name   string
    salary float64
}
func (e *Employee) incrementSalary(percentage float64) {
    e.salary += e.salary * percentage / 100
}
 
func (e Employee) display() {
    fmt.Println("Employee Name: " + e.name + ", Salary: " + strconv.FormatFloat(e.salary, 'f', 2, 64))
}
 

type EmpMgr struct {
    employees []*Employee
}

func (mgr *EmpMgr) add(emp *Employee) {
    mgr.employees = append(mgr.employees, emp)
}
 
func (mgr EmpMgr) displayAll() {
    for _, emp := range mgr.employees {
        emp.display()
    }
}
 
func main() {
	mgr := EmpMgr{}
	for i := 0; i < 5; i++ {
		emp := Employee{id: i + 1, name: "Emp" + strconv.Itoa(i+1), salary: float64(50000 + i*10000)}
		mgr.add(&emp)
		emp.incrementSalary(10)
	}
    
    mgr.displayAll()
}
