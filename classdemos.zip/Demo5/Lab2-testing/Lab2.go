package main

import "strconv"

func divide(s1, s2 string)  int {
	n1, _ := strconv.Atoi(s1)
	n2,_ := strconv.Atoi(s2)
	return n1/n2
}