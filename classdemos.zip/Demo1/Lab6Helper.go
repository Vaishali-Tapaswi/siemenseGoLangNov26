package main

import "fmt"


func helloworld(){
	fmt.Println("in Hello World function")
}

func calc(a , b int) (sum, sub int) {
	fmt.Println("in calc function")
	sum, sub = a+b, a-b
	return 
}

