package main

import "fmt"
func main() {
    var pow = []int{1, 2, 4, 8, 16, 32, 64, 128}
 
    for i, v := range pow {
        fmt.Printf("2**%d = %d\n", i, v)
    }
 
    m := make(map[string]int)
    m["one"] = 1
    m["two"] = 2
    m["three"] = 3
 
    for key, value := range m {
        fmt.Printf("%s = %d\n", key, value)
    }
    delete(m, "two")
    for key, value := range m {
        fmt.Printf("-- %s = %d\n", key, value)
    }
 
    fmt.Println("After deletion:", m["two"])
 
    // Check if "two" exists in the map after deletion
    value, ok := m["two"]
 
    fmt.Println("Value:", value, "Exists:", ok)
}
 