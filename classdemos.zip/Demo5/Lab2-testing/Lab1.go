package main

import "fmt"

func add(a , b int) int {
	fmt.Println("in add function")
	return a+b
}
func sub(a , b int) int {
	fmt.Println("in sub function")
	return a-b
}
func calc(a , b int) (int, int) {
	fmt.Println("in calc function")
	return a+b, a-b
}
func main() {
	
	result := add(5, 10)
	fmt.Println("Result of addition is:", result)
	result = sub(10, 5)
	fmt.Println("Result of subtraction is:", result)
	addResult, subResult := calc(10, 5)
	fmt.Println("Returned, sum =  ", addResult, "sub = ", subResult)
	
}
