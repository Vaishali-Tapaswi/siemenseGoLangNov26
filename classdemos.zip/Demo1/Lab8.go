package main
import "fmt"
func main(){
	fmt.Print("Enter Your Name and Age : ")
	var name string 
	age := 4
	//func Scanln(a ...any) (n int, err error)
	cnt, err := fmt.Scanln(&name, &age)
	
		fmt.Println("Error reading input:", err , "Count of scanned items:", cnt)
	fmt.Println("Your Name is :", name, "and Your Age is :", age)	
}