package main

import "fmt"

func process(a, b int, operation func(int,int) int) {
	fmt.Println("in process function with operation", operation)
	fmt.Println("Result of operation is:", operation(a,b))
	}	

func main() {
	process(10,5, add)
	process(10,5, sub)
}

func add(a , b int) int {
	fmt.Println("in add function")
	return a+b
}
func sub(a , b int) int {
	fmt.Println("in sub function")
	return a-b
}


