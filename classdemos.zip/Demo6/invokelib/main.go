package main

import (
	"fmt"
	"abc.com/calc"
)

func main() {
	fmt.Println("in main ")
	fmt.Println("Ans = ", calc.Add(10, 50))
	fmt.Println("Ans = ", calc.Sub(100, 50))
	fmt.Println("Ans = ", calc.Mult(10, 50))
}
