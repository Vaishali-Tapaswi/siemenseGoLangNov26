package main
 
import (
    "fmt"
    "sort"
)
 
func main() {
    var arr [5]int
    for i := 0; i < len(arr); i++ {
		fmt.Print("Enter Number ", i+1, " : ")
    	fmt.Scan(&arr[i])
  	}
	//: =  convert array to slice  
    sort.Ints(arr[:])
    fmt.Println(arr)

	var strarr [5]string
    for i := 0; i < len(strarr); i++ {
		fmt.Print("Enter String ", i+1, " : ")
    	fmt.Scan(&strarr[i])
  	}
	//: =  convert array to slice  
    sort.Strings(strarr[:])
    fmt.Println(strarr)



}
 