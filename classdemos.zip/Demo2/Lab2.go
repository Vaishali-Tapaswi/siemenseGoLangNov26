package main

import "fmt"

func process(base int) func(int) int{
	fmt.Println("in process function with base = ", base)
	return func(a int) int {
		fmt.Println("in return function")
		base = a+base
		return base
	}
}	

func main() {
	fp := process(10)
	fmt.Println("Result of fp is:", fp(10))
	fmt.Println("Result of fp is:", fp(10))
	fmt.Println("Result of fp is:", fp(10))
}


