package main

import (
    "database/sql"
    "log"
    "time"

    "github.com/gin-gonic/gin"
    _ "github.com/jackc/pgx/v5/stdlib"

    "abc.com/code/dbcomm"
    "abc.com/code/controller"
    "abc.com/code/types"
)

func main() {
    cfg, err := dbcomm.LoadDB("db.properties")
    if err != nil {
        log.Fatal(err)
    }

    db, err := sql.Open("pgx", cfg.DSN())
    if err != nil {
        log.Fatal(err)
    }
    defer db.Close()

    db.SetMaxOpenConns(10)
    db.SetMaxIdleConns(5)
    db.SetConnMaxLifetime(30 * time.Minute)

    if err := db.Ping(); err != nil {
        log.Fatalf("cannot connect to PostgreSQL: %v", err)
    }
    log.Println("Connected to PostgreSQL")

    repo := types.NewPostgresRepository(db)
    handler := controller.NewHandler(repo)

    router := gin.Default()
    handler.RegisterRoutes(router)

    log.Println("REST API listening on :8080")
    if err := router.Run(":8080"); err != nil {
        log.Fatal(err)
    }
}
