package main

import "testing"
func TestAdd(t *testing.T){
	got := add(10,20)
    if got != 30 {
        t.Errorf("add(10,20) = %d; want 30", got)
    }
}