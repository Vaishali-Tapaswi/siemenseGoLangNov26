package main

import "fmt"
func main() {
	var i int = 10 
	fmt.Println("Value of i is:", i)	
	var s string = "Hello, World!!!"
	fmt.Println("Value of s is:", s)

	j := 20 
	st1 := "Hi"
	fmt.Println("Value of j is:", j)
	fmt.Println("Value of st1 is:", st1)
	
	age, name := 30, "John"
	fmt.Println("Value of age is:", age)
	fmt.Println("Value of name is:", name)
	
	
}
