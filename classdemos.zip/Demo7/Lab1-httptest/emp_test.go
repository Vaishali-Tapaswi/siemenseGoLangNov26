package main

import (
    "bytes"
    "encoding/json"
    "net/http"
    "net/http/httptest"
    "os"
    "path/filepath"
    "testing"
)

type empTestCase struct {
    Name           string          `json:"name"`
    Payload        json.RawMessage `json:"payload"`
    ExpectedStatus int             `json:"expected_status"`
    ExpectedEmp    Employee        `json:"expected_emp"`
}

func TestCreateEmployeeHandlerFromJSON(t *testing.T) {
    // Read the external JSON test file
    filePath := filepath.Join("empcases.json")
    data, err := os.ReadFile(filePath)
    if err != nil {
       t.Fatalf("failed to read test file %s: %v", filePath, err)
    }

    // Unmarshal test cases into a slice
    var tests []empTestCase
    if err := json.Unmarshal(data, &tests); err != nil {
       t.Fatalf("failed to parse test JSON: %v", err)
    }

    for _, tc := range tests {
       t.Run(tc.Name, func(t *testing.T) {
          // tc.Payload is already raw JSON bytes ready for the request body
          req := httptest.NewRequest(http.MethodPost, "/employees", bytes.NewReader(tc.Payload))
          req.Header.Set("Content-Type", "application/json")
          rr := httptest.NewRecorder()

          // Execute handler
          CreateEmployeeHandler(rr, req)

          // Verify HTTP status code
          if rr.Code != tc.ExpectedStatus {
             t.Fatalf("expected status %d, got %d (body: %s)", tc.ExpectedStatus, rr.Code, rr.Body.String())
          }

          // Verify JSON response body on 201 Created
          if tc.ExpectedStatus == http.StatusCreated {
             var got Employee
             if err := json.NewDecoder(rr.Body).Decode(&got); err != nil {
                t.Fatalf("failed to decode response JSON: %v", err)
             }

             if got != tc.ExpectedEmp {
                t.Errorf("expected employee %+v, got %+v", tc.ExpectedEmp, got)
             }
          }
       })
    }
}

func TestDeleteEmployeeHandler(t *testing.T) {
    // Seed the store with a known employee.
    employees = map[int]Employee{
       201: {EmpNo: 201, EName: "Rahul Verma", Salary: 65000},
    }

    tests := []struct {
       name           string
       path           string
       expectedStatus int
    }{
       {"Delete existing employee", "/employees/201", http.StatusOK},
       {"Delete non-existing employee", "/employees/999", http.StatusNotFound},
    }

    for _, tc := range tests {
       t.Run(tc.name, func(t *testing.T) {
          req := httptest.NewRequest(http.MethodDelete, tc.path, nil)
          rr := httptest.NewRecorder()

          DeleteEmployeeHandler(rr, req)

          if rr.Code != tc.expectedStatus {
             t.Fatalf("expected status %d, got %d (body: %s)", tc.expectedStatus, rr.Code, rr.Body.String())
          }
       })
    }

    // The deleted employee must no longer be in the store.
    if _, stillThere := employees[201]; stillThere {
       t.Errorf("employee 201 should have been deleted")
    }
}
 