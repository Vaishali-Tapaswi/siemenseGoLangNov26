module myprop

go 1.25.1

require github.com/magiconair/properties v1.18.13
